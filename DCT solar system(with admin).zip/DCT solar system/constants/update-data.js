const UPDATE_DATA = [
  {
    imgSrc: "./images/solar.webp", // Replace with image of solar panel
    profileName: "DCT Solar team",
    message: "Your system generated X kWh of clean energy today!",
    updatedTime: "Today",
  },
  {
    imgSrc: "./images/solar.webp", // Replace with image of report
    profileName: "DCT Solar team",
    message: "We've received your request for a system monitoring report. It will be available in your inbox soon!",
    updatedTime: "Yesterday",
  },
  {
    imgSrc: "./images/solar.webp", // Replace with image of calendar
    profileName: "DCT Solar team",
    message: "Your next system maintenance is scheduled for [date]. A technician will be in touch to confirm details.",
    updatedTime: "Last Week",
  },
];
