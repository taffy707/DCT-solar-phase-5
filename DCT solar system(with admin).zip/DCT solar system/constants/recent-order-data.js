const RECENT_ORDER_DATA = [
  {
    productName: "solar",
    productNumber: "85631",
    payment: "paid",
    status: "installed",
    statusColor: "green",
  },
  {
    productName: "invertor",
    productNumber: "36378",
    payment: "not paid",
    status: "pending",
    statusColor: "green",
  },

];
