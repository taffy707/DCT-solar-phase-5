const RECENT_ORDER_DATA = [
    {
      productName: "Solar Panel (300W)",
      productNumber: "12345",
      payment: "Paid",
      status: "Shipped",
      statusColor: "green",
    },
    {
      productName: "Battery (10 kWh)",
      productNumber: "67890",
      payment: "Pending",
      status: "Processing",
      statusColor: "yellow",
    },
    {
      productName: "Inverter (5kW)",
      productNumber: "11122",
      payment: "Paid",
      status: "Installed",
      statusColor: "green",
    },
  ];