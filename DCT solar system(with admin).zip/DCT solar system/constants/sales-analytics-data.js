const SALES_ANALYTICS_DATA = [
  {
    itemClass: "online",
    icon: "shopping_cart",
    title: "Solars",
    colorClass: "success",
    percentage: "+39",
    sales: "R3849",
  },
  {
    itemClass: "offline",
    icon: "local_mall",
    title: "Batteries",
    colorClass: "danger",
    percentage: "-17",
    sales: "R1100",
  },
  {
    itemClass: "customers",
    icon: "person",
    title: "Invertors",
    colorClass: "danger",
    percentage: "+25",
    sales: "R849",
  },
];
